<?php
if (!empty($_POST)){}
$dbhost = "localhost";
$dbuser = "form_user";
$dbpass = "asdf";
$dbname = "reg_form";
$connection = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
if (mysqli_connect_errno()){
    die ("Database connection failed: " . mysqli_connect_error() . "(" . mysqli_connect_errno() . ")");
}
?>